# 🎉 Birthday Wish Website (Mobile Friendly + Typing Animation)

This is a romantic birthday wishing website with:
- 🎈 Balloons & cake animation
- 🎶 Background music
- ❤️ Love quiz with 3 questions
- 🎊 Confetti & fireworks animation
- 🔗 Auto-redirect to a surprise page after quiz
- 📱 Fully mobile responsive
- ✍️ Typing text animation for the birthday message

---

## ✅ Live Preview (after deploying)
You will get a link like:
```
https://your-birthday-wish.vercel.app
```

---

## 🚀 One-Click Deploy to Vercel
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/project?template=https://github.com/YOUR-GITHUB-USERNAME/YOUR-REPO-NAME)

---

### How to Use:
1. Replace `music.mp3` with your favorite romantic MP3.
2. Deploy using Vercel button or connect your GitHub repo to Vercel.

---

## ✨ Features
- Personalized name entry before showing wishes.
- Background animations, balloons, and cake.
- Auto-redirect to a surprise page after the quiz.
- Mobile responsive layout.
- Typing animation for the main birthday message.

---
Enjoy and share with your loved one! ❤️
