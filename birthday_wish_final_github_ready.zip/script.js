const questions = [
  "Do you love me more than chocolate? 🍫",
  "Would you go on a forever trip with me? 🌍",
  "Can I keep making you smile every day? 😊"
];

let currentQuestion = 0;
let userName = "";

function startBirthday() {
  userName = document.getElementById('name-input').value;
  if (!userName) {
    alert('Please enter your name!');
    return;
  }
  document.getElementById('name-screen').classList.add('hidden');
  document.getElementById('main-screen').classList.remove('hidden');
  document.getElementById('wish-text').innerText = `🎉 Happy Birthday, ${userName}! 🎂`;
}

function startQuestions() {
  document.querySelector('.start-btn').style.display = 'none';
  document.getElementById('questions').classList.remove('hidden');
  document.getElementById('question-box').innerText = questions[currentQuestion];
}

function answer(response) {
  if (response === 'No') {
    alert("Oh no! You broke my heart 😢 (Try again)");
    return;
  }
  currentQuestion++;
  if (currentQuestion < questions.length) {
    document.getElementById('question-box').innerText = questions[currentQuestion];
  } else {
    document.getElementById('questions').classList.add('hidden');
    document.getElementById('final-message').classList.remove('hidden');
    startConfetti();
    startFireworks();
    setTimeout(() => {
      window.location.href = 'surprise.html';
    }, 7000);
  }
}

function startConfetti() {
  const duration = 5 * 1000;
  const end = Date.now() + duration;

  (function frame() {
    confetti({
      particleCount: 3,
      angle: 60,
      spread: 55,
      origin: { x: 0 }
    });
    confetti({
      particleCount: 3,
      angle: 120,
      spread: 55,
      origin: { x: 1 }
    });

    if (Date.now() < end) {
      requestAnimationFrame(frame);
    }
  })();
}

function startFireworks() {
  const canvas = document.getElementById('fireworks');
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const fireworks = [];
  const particles = [];
  const colors = ['#ff4b5c', '#4b7bec', '#26de81', '#feca57', '#ff9f43'];

  function createFirework(x, y) {
    const color = colors[Math.floor(Math.random() * colors.length)];
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: x,
        y: y,
        speed: Math.random() * 5 + 2,
        angle: Math.random() * 2 * Math.PI,
        color: color,
        life: 100
      });
    }
  }

  function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      p.x += Math.cos(p.angle) * p.speed;
      p.y += Math.sin(p.angle) * p.speed;
      p.life--;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, 2, 2);
      if (p.life <= 0) {
        particles.splice(i, 1);
        i--;
      }
    }
    requestAnimationFrame(update);
  }

  setInterval(() => {
    createFirework(Math.random() * canvas.width, Math.random() * canvas.height);
  }, 500);

  update();
}
// Apply typing effect to the main wish
const wishElement = document.querySelector('.wish');
if(wishElement){wishElement.classList.add('typing');}
